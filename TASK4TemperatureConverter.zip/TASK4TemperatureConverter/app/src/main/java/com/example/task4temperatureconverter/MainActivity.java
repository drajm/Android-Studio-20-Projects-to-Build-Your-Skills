
package com.example.temperatureconverter;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.View;

import android.widget.Button;

import android.widget.EditText;

import android.widget.TextView;

import android.widget.Toast;



public class MainActivity extends AppCompatActivity {


    EditText tempInput;

    Button celsiusButton;

    Button fahrenheitButton;

    TextView resultText;



    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_main);



        // Connect XML components with Java


        tempInput = findViewById(R.id.tempInput);

        celsiusButton = findViewById(R.id.celsiusButton);

        fahrenheitButton = findViewById(R.id.fahrenheitButton);

        resultText = findViewById(R.id.resultText);



        // Celsius to Fahrenheit


        celsiusButton.setOnClickListener(new View.OnClickListener() {


            @Override

            public void onClick(View view) {


                String value = tempInput.getText().toString();



                if(value.isEmpty()){


                    Toast.makeText(

                            MainActivity.this,

                            "Please enter temperature",

                            Toast.LENGTH_SHORT

                    ).show();


                    return;

                }



                double celsius = Double.parseDouble(value);



                double fahrenheit =

                        (celsius * 9 / 5) + 32;



                resultText.setText(

                        String.format("%.2f °F", fahrenheit)

                );


                Toast.makeText(

                        MainActivity.this,

                        "Converted Successfully",

                        Toast.LENGTH_SHORT

                ).show();


            }

        });





        // Fahrenheit to Celsius


        fahrenheitButton.setOnClickListener(new View.OnClickListener() {


            @Override

            public void onClick(View view) {


                String value = tempInput.getText().toString();



                if(value.isEmpty()){


                    Toast.makeText(

                            MainActivity.this,

                            "Please enter temperature",

                            Toast.LENGTH_SHORT

                    ).show();


                    return;

                }



                double fahrenheit = Double.parseDouble(value);



                double celsius =

                        (fahrenheit - 32) * 5 / 9;



                resultText.setText(

                        String.format("%.2f °C", celsius)

                );



                Toast.makeText(

                        MainActivity.this,

                        "Converted Successfully",

                        Toast.LENGTH_SHORT

                ).show();


            }

        });


    }

}
