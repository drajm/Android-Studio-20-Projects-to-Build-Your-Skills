package com.example.task6notesapplication;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import java.util.List;

public class NoteViewModel extends AndroidViewModel {

    private NoteRepository repository;
    private LiveData<List<Note>> notes;
    private MutableLiveData<String> searchQuery = new MutableLiveData<>("%%");

    public NoteViewModel(@NonNull Application application) {
        super(application);
        repository = new NoteRepository(application);
        notes = Transformations.switchMap(searchQuery, query -> repository.searchNotes(query));
    }

    LiveData<List<Note>> getNotes() {
        return notes;
    }

    void setSearchQuery(String query) {
        searchQuery.setValue("%" + query + "%");
    }

    void insert(Note note) {
        repository.insert(note);
    }

    void delete(Note note) {
        repository.delete(note);
    }

    void update(Note note) {
        repository.update(note);
    }
}
