package com.example.task6notesapplication;

import android.app.Application;
import androidx.lifecycle.LiveData;
import java.util.List;

public class NoteRepository {

    private NoteDao noteDao;
    private LiveData<List<Note>> allNotes;

    public NoteRepository(Application application) {
        NoteDatabase database = NoteDatabase.getDatabase(application);
        noteDao = database.noteDao();
        allNotes = noteDao.getAllNotes();
    }

    LiveData<List<Note>> getAllNotes() {
        return allNotes;
    }

    LiveData<List<Note>> searchNotes(String search) {
        return noteDao.searchNotes(search);
    }

    void insert(Note note) {
        new Thread(() -> noteDao.insert(note)).start();
    }

    void delete(Note note) {
        new Thread(() -> noteDao.delete(note)).start();
    }

    void update(Note note) {
        new Thread(() -> noteDao.update(note)).start();
    }
}
