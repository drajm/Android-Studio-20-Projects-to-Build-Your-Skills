package com.example.task7quizapplication;

public class Question {
    String question;
    String optionA;
    String optionB;
    String optionC;
    String answer;

    public Question(String question, String optionA, String optionB, String optionC, String answer) {
        this.question = question;
        this.optionA = optionA;
        this.optionB = optionB;
        this.optionC = optionC;
        this.answer = answer;
    }
}
