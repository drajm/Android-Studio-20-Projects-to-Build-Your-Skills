package com.example.task7quizapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.os.CountDownTimer;
import android.widget.*;
import java.util.ArrayList;

public class QuizActivity extends AppCompatActivity {

    TextView questionText, questionNumber, timerText;
    RadioButton optionA, optionB, optionC;
    RadioGroup optionsGroup;
    Button submitButton;
    ProgressBar progressBar;

    ArrayList<Question> questions;
    int currentQuestion = 0;
    int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        questionText = findViewById(R.id.questionText);
        questionNumber = findViewById(R.id.questionNumber);
        timerText = findViewById(R.id.timerText);
        optionA = findViewById(R.id.optionA);
        optionB = findViewById(R.id.optionB);
        optionC = findViewById(R.id.optionC);
        optionsGroup = findViewById(R.id.optionsGroup);
        submitButton = findViewById(R.id.submitButton);
        progressBar = findViewById(R.id.progressBar);

        loadQuestions();
        progressBar.setMax(questions.size());
        showQuestion();
        startTimer();

        submitButton.setOnClickListener(v -> {
            int selectedId = optionsGroup.getCheckedRadioButtonId();
            if (selectedId != -1) {
                RadioButton selectedOption = findViewById(selectedId);
                String answer = selectedOption.getText().toString();

                if (answer.equals(questions.get(currentQuestion).answer)) {
                    score++;
                }

                currentQuestion++;
                if (currentQuestion < questions.size()) {
                    showQuestion();
                } else {
                    finishQuiz();
                }
            } else {
                Toast.makeText(QuizActivity.this, "Please select an answer", Toast.LENGTH_SHORT).show();
            }
        });
    }

    void loadQuestions() {
        questions = new ArrayList<>();
        questions.add(new Question("What is Android?", "Linux OS", "Database", "Browser", "Linux OS"));
        questions.add(new Question("What language is used for Android?", "Java", "HTML", "SQL", "Java"));
    }

    void showQuestion() {
        Question q = questions.get(currentQuestion);
        questionText.setText(q.question);
        optionA.setText(q.optionA);
        optionB.setText(q.optionB);
        optionC.setText(q.optionC);

        questionNumber.setText("Question " + (currentQuestion + 1) + "/" + questions.size());
        progressBar.setProgress(currentQuestion + 1);
        optionsGroup.clearCheck();
    }

    void startTimer() {
        new CountDownTimer(30000, 1000) {
            public void onTick(long millis) {
                timerText.setText("Time: " + millis / 1000);
            }
            public void onFinish() {
                finishQuiz();
            }
        }.start();
    }

    void finishQuiz() {
        Intent intent = new Intent(QuizActivity.this, ResultActivity.class);
        intent.putExtra("score", score);
        startActivity(intent);
        finish();
    }
}
