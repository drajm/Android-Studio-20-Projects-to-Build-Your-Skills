package com.example.task3_calculatorapp;  // <-- Match your namespace

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.task3_calculatorapp.R;  // <-- Import R from your package

public class MainActivity extends AppCompatActivity {

    private EditText number1;
    private EditText number2;
    private Button addButton;
    private Button subButton;
    private Button mulButton;
    private Button divButton;
    private Button clearButton;
    private TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initializeViews();
        setButtonListeners();
    }

    private void initializeViews() {
        number1 = findViewById(R.id.number1);
        number2 = findViewById(R.id.number2);
        addButton = findViewById(R.id.addButton);
        subButton = findViewById(R.id.subButton);
        mulButton = findViewById(R.id.mulButton);
        divButton = findViewById(R.id.divButton);
        clearButton = findViewById(R.id.clearButton);
        resultText = findViewById(R.id.resultText);
    }

    private void setButtonListeners() {
        addButton.setOnClickListener(v -> calculate('+'));
        subButton.setOnClickListener(v -> calculate('-'));
        mulButton.setOnClickListener(v -> calculate('*'));
        divButton.setOnClickListener(v -> calculate('/'));
        clearButton.setOnClickListener(v -> clearAll());
    }

    private void calculate(char operation) {
        if (!validateInput()) {
            return;
        }

        try {
            double a = getNumber1();
            double b = getNumber2();
            double result = 0;
            String operationSymbol = "";

            switch (operation) {
                case '+':
                    result = a + b;
                    operationSymbol = " + ";
                    break;
                case '-':
                    result = a - b;
                    operationSymbol = " - ";
                    break;
                case '*':
                    result = a * b;
                    operationSymbol = " × ";
                    break;
                case '/':
                    if (b == 0) {
                        resultText.setText("Cannot divide by zero!");
                        Toast.makeText(this, "Division by zero is not allowed", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    result = a / b;
                    operationSymbol = " ÷ ";
                    break;
                default:
                    return;
            }

            String calculation = a + operationSymbol + b + " = " + result;
            resultText.setText(calculation);

        } catch (NumberFormatException e) {
            resultText.setText("Error: Invalid number format");
            Toast.makeText(this, "Please enter valid numbers", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            resultText.setText("Error: " + e.getMessage());
            Toast.makeText(this, "An error occurred", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean validateInput() {
        String num1 = number1.getText().toString().trim();
        String num2 = number2.getText().toString().trim();

        if (num1.isEmpty() || num2.isEmpty()) {
            resultText.setText("Please enter both numbers!");
            Toast.makeText(this, "Both fields are required", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private double getNumber1() throws NumberFormatException {
        String text = number1.getText().toString().trim();
        if (text.isEmpty()) {
            throw new NumberFormatException("Number 1 is empty");
        }
        return Double.parseDouble(text);
    }

    private double getNumber2() throws NumberFormatException {
        String text = number2.getText().toString().trim();
        if (text.isEmpty()) {
            throw new NumberFormatException("Number 2 is empty");
        }
        return Double.parseDouble(text);
    }

    private void clearAll() {
        number1.setText("");
        number2.setText("");
        resultText.setText("Result: ");
        number1.requestFocus();
        Toast.makeText(this, "Cleared all fields", Toast.LENGTH_SHORT).show();
    }
}